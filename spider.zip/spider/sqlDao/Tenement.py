# -*- coding: utf-8 -*-
"""
@auther = wangxiaotao
created on 2017-7-4
"赶集网爬虫数据库存储"
"""

from sqlalchemy import create_engine
from sqlalchemy import Table, Column, Integer, String, ForeignKey
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

engine = create_engine('sqlite:///ganji_tenement.sqlite', echo=True)  # 三条杆默认相对路径，四条杠绝对路径

Base = declarative_base()
DBSession = sessionmaker(bind=engine)
session = DBSession()


class Tenement(Base):
    __tablename__ = "tenement"
    id = Column(Integer, primary_key=True)
    title = Column(String(400))
    price = Column(String(400))
    info = Column(String(400))
    people = Column(String(400))
    address = Column(String(400))

    @classmethod
    def save(cls, data):
        session.add(data)
        session.commit()
        return data.id

Base.metadata.create_all(engine)
