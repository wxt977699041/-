# -*- coding: utf-8 -*-
"""
@auther = wangxiaotao
created on 2017-7-4
"爬取赶集网租房信息"
"""
import requests
from lxml import etree
from time import sleep
from sqlDao.Tenement import *
from utilDao.util import agent_ip, requests_headers


def requests_view(response):
    import webbrowser

    request_url = response.url
    base_url = '<head><base href="%s">' % (request_url)
    base_url = base_url.encode()
    content = response.content.replace(b"<head>", base_url)
    tem_html = open("tmp.html", 'wb')
    tem_html.write(content)
    tem_html.close()
    webbrowser.open_new_tab("tmp.html")


def parse_data(response):
    html = etree.HTML(response.content.decode())
    items = html.xpath(".//div[@class='f-main-list']/div/div[contains(@class,'f-list-item')]")
    for i in items:
        title = i.xpath(".//dd[@class='dd-item title']/a/text()")
        price = i.xpath(".//dd[@class='dd-item info']/div[@class='price']/span/text()")
        info = i.xpath(".//dd[@class='dd-item size']/span/text()")
        people = i.xpath(".//dd[@class='dd-item source']/span/text()")
        address = i.xpath(".//dd[@class='dd-item address']/span[@class='area']/a[@class='address-eara']/text()")
        zf = Tenement()
        zf.title = " ".join(title)
        zf.price = " ".join(price)
        zf.info = " ".join(info)
        zf.people = " ".join(people)
        zf.address = " ".join(address)
        zf.save(zf)


if __name__ == '__main__':

    base_url = "http://bj.ganji.com/fang1/0{}/"
    for i in range(1, 1000000):
        request_url = base_url.format(i)
        # proxies = agent_ip()
        # print(proxies)
        response = requests.get(request_url, proxies={"http": "http://{}".format(agent_ip())}, headers=requests_headers())
        print(request_url, "status_code:", response.status_code)
        try:
            parse_data(response)
        except:
            pass
