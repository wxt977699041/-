# -*- coding: utf-8 -*-
"""
@auther = wangxiaotao
created on 2017-7-4
"爬虫第一个练习"
"""
import requests
from lxml import etree
from time import sleep
import sys

# sys.setrecursionlimit()   ###设置递归的最大次数


def down_pic(imgs):
    file_dir = "f:/Python_spider_src/new/{}"
    for i in imgs:
        file_name = i.split("/")[-1]  # 斜杠分割，获取最后一个
        file_content = requests.get(i.strip())
        print(file_name)
        if file_content.status_code != 200:
            print(i, file_content.status_code)
        else:
            try:
                with open(file_dir.format(file_name), 'wb') as f:  # 二进制的写
                    f.write(file_content.content)
            except:
                print(file_name)


def all_links(url):
    response = requests.get(url)
    print(url, response.status_code)
    html = etree.HTML(response.content)

    # 获取图片和下载图片
    imgs = html.xpath(".//div[@id='wrapper']//div[@class='ui-module']//img/@src")   ###获取图片链接
    print(imgs)
    down_pic(imgs)  ###下载图片的函数

    links = html.xpath(".//div[@class='page']//a[contains(text(), '下一页')]/@href")   ###获取下一页的链接
    print(links)
    if len(links  ) < 1:
        pass
    else:
        sleep(0.001)
        host = "http://www.qiubaichengren.com/"
        all_links(host + links[0])  ###函数递归


def main():
    all_links("http://www.qiubaichengren.com/")


if __name__ == '__main__':
    main()
