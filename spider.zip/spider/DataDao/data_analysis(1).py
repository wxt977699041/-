# -*- coding: utf-8 -*-
"""
@auther = wangxiaotao
created on 2017-7-6
"对爬取到的数据进行分析"
"""

import pygal
from Ipython.display import HTML
from Practice.spider.sqlDao.Tenement import Tenement

"""
pip install pygal
pip install cairosvg 作用：链接cairo的库文件
linux和mac报错OSErro：sudo apt-get install cairo
"""
line_chart = pygal.Line()
line_chart.title = '北京房屋出租信息统计'
line_chart.x_labels = map(str, range(2012, 2013))

HTML(line_chart.render().decode())
